### R script to calculate a genetic map using ASMap ( MSTmap )
### December 2021
### Luzie U. Wingen, John Innes Centre, UK
install.packages('ASMap') ### comment out after you installed ASMap 
library(ASMap)

gtfn <- 'data/PxW141 KASP data.csv' ### name of the genotype file
gts <- read.csv(gtfn,as.is=T,row.names=1) ### read genotype file
gts[gts=='H'] <- 'X' ### change genotypes 'H' to 'X'
poptype='RIL5' ### define the population type. It can also be 'DH'
####ASMpvalue=1e-6 ### try different thresholds for map creation
###ASMpvalue=1e-8  ### try different thresholds for map creation
ASMpvalue=1e-9### try different thresholds for map creation
mstMC <- mstmap.data.frame(gts, pop.type = poptype, dist.fun = "kosambi",objective.fun = "COUNT", p.value = ASMpvalue, noMap.dist = 30, noMap.size = 2,miss.thresh = 10, mvest.bc = FALSE, traces=TRUE,as.cross=TRUE)
### extract the map
mymap <- pull.map(mstMC)
unlinkedLGs <- names(mymap[sapply(mymap,length)<2])### unlinked markers
linkedLGs<- names(mymap[sapply(mymap,length)>1])### linked markers 
### select only the linked markers
mstMClinked <- subsetCross(mstMC,chr=linkedLGs)
### pull the map out of the complex cross object
mymap <- pull.map(mstMClinked)
### plot the map
plot(mymap,horizontal=TRUE,main='Genetic Map of Paragon x Watkins141 (ASMap initial)')
### check how man linkage groups are there?
### I count 63 - rather a lot, given that we have 21 chromosomes.
### Try to join up linkage groups - by chromosome names attached to the markers

### create a list of the common chromosome name for each linkage groups
chromosomeL <- list()
for (i in 1:length(mymap))
{
    lgnames <-names(sort(summary(as.factor(sub("^.*[_-]",'',names(mymap[[i]])))),decreasing=TRUE))
    lgnames <- lgnames[lgnames!='']### remove missing names
    if (lgnames[1]%in%names(chromosomeL)) ### append list
        chromosomeL[lgnames[1]] <- list(c(chromosomeL[[lgnames[1]]],names(mymap)[i]))
    else ### add a new chromosome to the list
        chromosomeL[lgnames[1]] <- list(names(mymap)[i])
}
### print the list of chromosomes and the linkage groups belonging to these chromosomes
print(chromosomeL)
### try to merge linkage groups that come from the same chromosome
for (chro in sort(names(chromosomeL))) ### loop through the sorted chromosome names
{
    lgs <- chromosomeL[chro]
    if (length(lgs[[1]]) > 1) ### try to merge linkage groups if there are several
    {
        print(chro)
        mstMClinked <- mergeCross(mstMClinked,merge=lgs,gap=10) ### merge
        mstMClinked <- mstmap(mstMClinked,p.value=1e-2,bychr=TRUE,chr=chro) ### separate linkage groups only if they are still not linked using a very permissive p-value of 1e-2
    }
    else ### rename the linkage group by chromosome
        names(mstMClinked$geno)[names(mstMClinked$geno)==lgs] <- chro
}
mymap <- pull.map(mstMClinked)
plot(mymap,horizontal=TRUE,main='Genetic Map of Paragon x Watkins141 (ASMap final)')
write.cross(mstMClinked, format=c("csvr"), filestem="R_out/PxW141_map_by_ASMap")

 
